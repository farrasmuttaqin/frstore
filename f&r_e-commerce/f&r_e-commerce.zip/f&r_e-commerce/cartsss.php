<?php
error_reporting(E_ERROR | E_PARSE);
                		
session_start();
   	
    if  ($_GET["id_cart"]==""||$_SESSION["emailq"]=="")
    {
        echo "<script> window.location.assign('index.php'); </script>";
    }
    else
    {
        $id_cart=$_GET["id_cart"];
        $email=$_SESSION["emailq"];
        $conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
    
        $sql = "DELETE FROM cart WHERE id_cart=$id_cart";

        if ($conn->query($sql) === TRUE) {
            echo "<script> window.location.assign('carts.php'); </script>";
        } else {
            echo "Error updating record: " . $conn->error;
        }
        $conn->close();
    }
    echo "<script> window.location.assign('index.php'); </script>";
?>