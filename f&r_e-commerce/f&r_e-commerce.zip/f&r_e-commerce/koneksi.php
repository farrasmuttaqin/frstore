<?php
    class db
    {
        public $server = "localhost";
        public $username = "id4159098_fashionlc";
        public $password = "farras9988";
        public $database = "id4159098_fashion";
    }
?>