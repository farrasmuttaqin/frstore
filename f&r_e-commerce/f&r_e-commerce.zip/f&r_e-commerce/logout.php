
				<?php
				    error_reporting(E_ERROR | E_PARSE);
				    session_start();
				    $_SESSION["namaq"]="";
				    $_SESSION["emailq"]="";
                    session_unset();
                    session_destroy();
                    
				        echo "<script> window.location.assign('login.php'); </script>";
                              
				
				?>
			