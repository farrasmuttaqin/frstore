<?php
    require_once "koneksi.php";
    $z = new db();
		
		/* ambil email dan password dari login.php */
	$email = $_GET["email"];
	
		/* memulai koneksi database */
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
		/* mengakses table admin untuk authorized login */
	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($con,$sql);
	
	$xml = new SimpleXMLElement("<data-cekPassword/>");
	while ($row = mysqli_fetch_assoc ($result))
	{
		$em = $xml->addChild("password", $row["pass"]);
	}
	
		/* menampilkan data dalam bentuk file xml */
	echo $xml->asXml();
	mysqli_free_result($result);
	
		/* menutup koneksi database */
	mysqli_close($con);
?>