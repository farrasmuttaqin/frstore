<?php
	
	require_once "koneksi.php";
     $z = new db();
    
	$email = $_GET["emails"];
	
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	$sql = "SELECT * FROM users WHERE email = '$email'";
	
	$result=mysqli_query($con,$sql);
	
	$xml = new SimpleXMLElement("<data-login/>");
	while ($row = mysqli_fetch_assoc ($result))
	{
		$nama = $xml->addChild("id", $row["id_user"]);
		$nama -> addAttribute("nama", $row["nama_lengkap"]);
		$nama -> addAttribute("Email",$row["email"]);
		$nama -> addAttribute("awal",$row["awal_join"]);
		$nama -> addAttribute("hash",$row["hashh"]);
		$nama -> addAttribute("active",$row["active"]);
	}
	
		/* menampilkan data dalam bentuk file xml */
	echo $xml->asXml();
	mysqli_free_result($result);
	
		/* menutup koneksi database */
	mysqli_close($con);
?>