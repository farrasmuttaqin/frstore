<?php
    require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$sql = "select paket,harga from kurir";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_kurir/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $nama=$xml->addChild("paket",$row["paket"]);
	    $nama->addAttribute("harga",$row["harga"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>