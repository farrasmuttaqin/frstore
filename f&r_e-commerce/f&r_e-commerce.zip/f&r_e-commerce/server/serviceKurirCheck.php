<?php
    require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);

    $tampungg = $_GET["pakett"];
	
	$sql = "select * from kurir where paket='$tampungg'";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_kurirCheck/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $harga=$xml->addChild("paket",$row["paket"]);
	    $harga->addAttribute("harga",$row["harga"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>