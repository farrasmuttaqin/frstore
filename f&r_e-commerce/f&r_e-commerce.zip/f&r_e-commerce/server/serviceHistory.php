<?php

    require_once "koneksi.php";
    $z = new db();
    
    $email=$_GET["email"];
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$sql = "select * from transfer_pembayaran where email='$email'";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_history/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kode=$xml->addChild("kode",$row["kode_transfer"]);
	    $kode->addAttribute("invoice",$row["nomor_invoice"]);
	    $kode->addAttribute("tgl_invoice",$row["tgl_invoice"]);
	    $kode->addAttribute("jenis_paket",$row["jenis_paket"]);
	    $kode->addAttribute("tujuan",$row["tujuan_pengiriman"]);
	    $kode->addAttribute("biaya",$row["total_bayar"]);
	    $kode->addAttribute("status_pembayaran",$row["status_pembayaran"]);
	    $kode->addAttribute("status_penerimaan",$row["status_penerimaan_barang"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>