<?php
	
	require_once "koneksi.php";
     $z = new db();
    
	$email = $_GET["emaill"];
	
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	$sql = "SELECT * FROM cart WHERE email = '$email' AND nomor_invoice=101";
	
	$result=mysqli_query($con,$sql);
	
	$xml = new SimpleXMLElement("<data-login/>");
	while ($row = mysqli_fetch_assoc ($result))
	{
		$nama = $xml->addChild("id_cart", $row["id_cart"]);
		$nama -> addAttribute("kode_product", $row["kode_product"]);
		$nama -> addAttribute("quantity", $row["quantity"]);
		$nama -> addAttribute("nama_product", $row["nama_product"]);
		$nama -> addAttribute("harga_product",$row["harga_product"]);
		$nama -> addAttribute("gambar_product",$row["gambar_product"]);
		$nama -> addAttribute("jenis_product",$row["jenis_product"]);
	}
	
		/* menampilkan data dalam bentuk file xml */
	echo $xml->asXml();
	mysqli_free_result($result);
	
		/* menutup koneksi database */
	mysqli_close($con);
?>