<?php
     require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$nominal=$_GET["tampungss"];
	$kode=$_GET["tampungsss"];
	$sql = "select * from transfer_pembayaran where kode_transfer='$kode' and total_bayar=$nominal ";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_cekAlfian/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kode=$xml->addChild("kode",$row["kode_transfer"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>