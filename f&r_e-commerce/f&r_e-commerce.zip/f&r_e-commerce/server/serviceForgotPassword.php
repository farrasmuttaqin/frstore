<?php

    require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
		/* ambil email dan password dari login.php */
		
	$email = $_GET["emaill"];
	
	
		/* mengakses table admin untuk authorized login */
	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query ($con,$sql);
	
	$xml = new SimpleXMLElement("<data-forgotPassword/>");
	while ($row = mysqli_fetch_assoc ($result))
	{
		$em = $xml->addChild("em", $row["email"]);
		$em -> addAttribute("pas",$row["pass"]);
		$em -> addAttribute("id_user",$row["id_user"]);

	}
	
		/* menampilkan data dalam bentuk file xml */
	echo $xml->asXml();
	mysqli_free_result($result);
	
		/* menutup koneksi database */
	mysqli_close($con);
?>