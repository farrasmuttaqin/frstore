<?php
    require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$sql = "select * from transfer_pembayaran";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_transfer/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kode=$xml->addChild("kode",$row["kode_transfer"]);
	    $kode->addAttribute("invoice",$row["nomor_invoice"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>