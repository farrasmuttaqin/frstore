<?php
     require_once "koneksi.php";
     $z = new db();
    
	$con = mysqli_connect($z->server,$z->username,$z->password,$z->database);
	
	$tampung=$_GET["tampungs"];
    $status="Belum Bayar";
	
	$sql = "select * from transfer_pembayaran where kode_transfer='$tampung' and status_pembayaran='$status'";
	
	$result = mysqli_query($con,$sql);
	
	
	$xml = new SimpleXMLElement("<data_cekAlfian/>");
	while ($row = mysqli_fetch_assoc($result))
	{
	    $kode=$xml->addChild("kode",$row["kode_transfer"]);
	    $kode->addAttribute("invoice",$row["nomor_invoice"]);
	    $kode->addAttribute("nama",$row["nama_lengkap"]);
	    $kode->addAttribute("email",$row["email"]);
	    $kode->addAttribute("biaya",$row["total_bayar"]);
	    $kode->addAttribute("tgl_cetak_invoice",$row["tgl_invoice"]);
	}
	
	echo $xml->asXml();
	mysqli_free_result($result);
	mysqli_close($con);
?>