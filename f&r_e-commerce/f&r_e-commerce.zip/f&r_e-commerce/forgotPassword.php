
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" type="image/x-icon" href="https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/31944804_119859008880931_7680956372128628736_n.jpg?_nc_cat=0&oh=0a6a6a255aeae4fc881a1d9aff57420e&oe=5B98BF94" />
<title>f&r Store | Forgot Password</title>

	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/linearicons-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Fashion Club Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- css -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css" media="all" />
<!--// css -->
<!-- font -->
<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!-- //font -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.js"></script>
</head>
<body class="animsition">
<div class="header-top-w3layouts">
	<div class="container">
		<div class="col-md-6 logo-w3">
			<a href="index.html"><img src="images/logo2.png" alt=" " /><h1>f&r Store</h1></a>
		</div>
		<div class="col-md-6 phone-w3l">
			<ul>
				<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span></li>
				<li>+62 812 9688 6565</li>
				<br>
		            <?php
		               error_reporting(E_ERROR | E_PARSE);
                		
                		session_start();
                		
                    		if ($_SESSION["namaq"]=="")
                    		{
                    		    echo " <li><a href='login.php'>Login </a>/</li>
                        			   <li><a href='register.php'>Register</a></li>
                        			   <br>";
                    		}
                    		else
                    		{
                    		    echo "<script> window.location.assign('index.php'); </script>";
                    		    
                    		}

                    ?>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<div class="header-bottom-w3ls">
	<div class="container">
		<div class="col-md-7 navigation-agileits">
			<nav class="navbar navbar-default">
				<div class="navbar-header nav_2">
					<button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse" data-target="#bs-megadropdown-tabs">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				</div> 
				<div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
					<ul class="nav navbar-nav ">
						<li class=" active"><a href="index.php" class="hyper "><span>Home</span></a></li>	
						<li class="dropdown ">
							<a href="#" class="dropdown-toggle  hyper" data-toggle="dropdown" ><span>Shop <b class="caret"></b></span></a>
								<ul class="dropdown-menu multi">
									<div class="row">
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<li><a href="jersey.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Jersey</a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<li><a href="merchandise.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Merchandise</a></li>
											</ul>
										</div>
										<div class="col-sm-4">
											<ul class="multi-column-dropdown">
												<li><a href="furniture.php"><i class="fa fa-angle-right" aria-hidden="true"></i>Furniture</a></li>
											</ul>
										</div>
										<div class="clearfix"></div>
									</div>	
								</ul>
						</li>
						
						<li><a href="about.php" class="hyper"><span>About</span></a></li>
						<li><a href="contact.php" class="hyper"><span>Contact Us</span></a></li>
					</ul>
				</div>
			</nav>
		</div>
					<script>
				$(document).ready(function(){
					$(".dropdown").hover(            
						function() {
							$('.dropdown-menu', this).stop( true, true ).slideDown("fast");
							$(this).toggleClass('open');        
						},
						function() {
							$('.dropdown-menu', this).stop( true, true ).slideUp("fast");
							$(this).toggleClass('open');       
						}
					);
				});
				</script>			
		<div class="col-md-4 search-agileinfo">
			<form action="search.php" method="get">
				<input type="search" name="search" placeholder="Mencari Nama Produk..." required="">
				<button type="submit" class="btn btn-default search" aria-label="Left Align">
					<i class="fa fa-search" aria-hidden="true"> </i>
				</button>
			</form>
		</div>
		<?php
    
    $email=$_SESSION["emailq"];
                    	
	$curl = curl_init();
    curl_setopt($curl , CURLOPT_URL, "http://farrasmuttaqin1.000webhostapp.com/server/serviceCart.php?emaill=$email");
	curl_setopt($curl , CURLOPT_HEADER,0);
	curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
	$xml = new SimpleXMLElement(curl_exec($curl));
	curl_close($curl);
	
	$cnt=0;
	
	foreach($xml->id_cart as $id_cart):
	    $cnt++;
	endforeach;
	
	echo "
	
	<div class='col-md-1 cart-wthree'>
		    <form>
		        	<button class='w3view-cart' type='submit' name='submit' value=''>
					</button>
    			<div class='icon-header-item cl2 hov-cl1 trans-04 p-l-22 p-r-11 icon-header-noti js-show-cart' data-notify='$cnt'>
        			<i class='zmdi zmdi-shopping-cart'></i>
        		</div>
    		</form>
		</div>
	
	";

?>
		<div class="clearfix"></div>
	</div>
</div>
<?php
    
    $email=$_SESSION["emailq"];
    
    if ($email=="")
    {
        echo "";
    }
    else
    {
                    	
    	$curl = curl_init();
        curl_setopt($curl , CURLOPT_URL, "http://farrasmuttaqin1.000webhostapp.com/server/serviceCart.php?emaill=$email");
    	curl_setopt($curl , CURLOPT_HEADER,0);
    	curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
    	$xml = new SimpleXMLElement(curl_exec($curl));
    	curl_close($curl);
    	
    	echo "
    	
    	<div class='wrap-header-cart js-panel-cart'>
    		<div class='s-full js-hide-cart'></div>
    
    		<div class='header-cart flex-col-l p-l-65 p-r-25'>
    			<div class='header-cart-title flex-w flex-sb-m p-b-8'>
    				<span class='mtext-103 cl2'>
    					Your Cart
    				</span>
    
    				<div class='fs-35 lh-10 cl2 p-lr-5 pointer hov-cl1 trans-04 js-hide-cart'>
    					<i class='zmdi zmdi-close'></i>
    				</div>
    			</div>
    			
    			<div class='header-cart-content flex-w js-pscroll'>
    				<ul class='header-cart-wrapitem w-full'>
    	
    	";
    	$total=0;
    	foreach($xml->id_cart as $id_cart):
    	    $nama_product=$id_cart["nama_product"];
    	    $harga_product=$id_cart["harga_product"];
    	    $jenis_product=$id_cart["jenis_product"];
    	    $kode_product=$id_cart["kode_product"];
    	    $quantity=$id_cart["quantity"];
            
            if ($jenis_product=="jersey")
            {
                $urlGambar = "http://renjershop.000webhostapp.com/server/jersey/";
            }
            if ($jenis_product=="merchandise")
            {
                $urlGambar = "http://ahmadfaiz309.000webhostapp.com/server/merchandise/";
            }
            if ($jenis_product=="furniture")
            {
                $urlGambar = "http://rafiirizqullah23.000webhostapp.com/server/furniture/";
            }
            
    	    $gambar_product=$urlGambar.$id_cart["gambar_product"];
            
            
    	    echo "
    	    
    	    <li class='header-cart-item flex-w flex-t m-b-12'>
    			<div class='header-cart-item-img'>
    				<img src='$gambar_product'>
    			</div>
    
    			<div class='header-cart-item-txt p-t-0'>
    				<a href='product.php?idd=$kode_product&tmp=$jenis_product' class='header-cart-item-name m-b-18 hov-cl1 trans-04'>
    					$nama_product
    				</a>
    
    				<span class='header-cart-item-info'>
    					$quantity x Rp ".strrev(implode('.',str_split(strrev(strval($harga_product)),3))).",-
    				</span>
    			</div>
    		</li>
    		<li><br></li>";
    		
        $total=($quantity*$harga_product)+$total;
    	endforeach;
        
        echo "
                    </ul>
    				<div class='w-full'>
    					<div class='header-cart-total w-full p-tb-40'>
    						Total: Rp ".strrev(implode('.',str_split(strrev(strval($total)),3))).",-
    					</div>
    
    					<div class='header-cart-buttons flex-w w-full'>";
    					
    					if ($total>0)
    						{
    						echo "
        						<a href='carts.php' class='flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-r-8 m-b-10'>
        							View Cart
        						</a>
        						<a href='checkcheck.php' class='flex-c-m stext-101 cl0 size-107 bg3 bor2 hov-btn3 p-lr-15 trans-04 m-b-10'>
        							Check Out
        						</a>";
    						}
    						echo "
        						
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
        ";
    }
?>
	<div class="login">
	
		<div class="main-agileits">
				<div class="form-w3agile" align="center">
					<h3>Lupa Password ?</h3>
					<form action="forgotPassword.php" method="post">
						<div class="key">
							<i class="fa fa-envelope" aria-hidden="true"></i>
							<input style="color:black;" type="text" name="Email" pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$" placeholder="Masukkan Email.." title="Harus sesuai dengan format email" required>
							<div class="clearfix"></div>
						</div>
						<input type="submit" name="Submit" value="Kirim">
						<br>
						<?php
        	                error_reporting(E_ERROR | E_PARSE);
                    		
                            $email = $_POST["Email"];
                            $eem=$email;
                	        if ($email=="")
                	        {
                	            echo "";
                	        }
                	        else
                	        {
                                $curl = curl_init();
                        		curl_setopt($curl , CURLOPT_URL, "http://farrasmuttaqin1.000webhostapp.com/server/serviceForgotPassword.php?emaill=$email");
                        		curl_setopt($curl , CURLOPT_HEADER,0);
                        		curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
                        		$xml = new SimpleXMLElement(curl_exec($curl));
                        		curl_close($curl);
                        		
                        		$nm="";
                        		foreach($xml->em as $emailLupa) :
                        			$nm=$emailLupa;
                        			$nmPass=$emailLupa["pas"];
                        		endforeach;
                            
                                
                            		if ($nm=="")
                            		{
                            		    echo "<h4 style='color:red;'>Email belum terdaftar, Silahkan daftar terlebih dahulu</h4>";
                            		}
                            		else
                            		{
                            		    echo "<h4 style='color:green;'>Password telah dikirim, silahkan cek email anda</h4>";
                                        
                                        $email = "frstoreee@gmail.com";
                                        
                                        $to = $nm;
                                        $subject = "Forgot Password | Verification";
                                        $message = "
                                        
                                         <!DOCTYPE html>
<html lang='en' xmlns='http://www.w3.org/1999/xhtml' xmlns:v='urn:schemas-microsoft-com:vml' xmlns:o='urn:schemas-microsoft-com:office:office'>
<head>
    <meta charset='utf-8'> <!-- utf-8 works for most cases -->
    <meta name='viewport' content='width=device-width'> <!-- Forcing initial-scale shouldn't be necessary -->
    <meta http-equiv='X-UA-Compatible' content='IE=edge'> <!-- Use the latest (edge) version of IE rendering engine -->
    <meta name='x-apple-disable-message-reformatting'>  <!-- Disable auto-scale in iOS 10 Mail entirely -->
    <title></title> <!-- The title tag shows in email notifications, like Android 4.4. -->

    <!-- Web Font / @font-face : BEGIN -->
    <!-- NOTE: If web fonts are not required, lines 10 - 27 can be safely removed. -->

    <!-- Desktop Outlook chokes on web font references and defaults to Times New Roman, so we force a safe fallback font. -->
    <!--[if mso]>
        <style>
            * {
                font-family: sans-serif !important;
            }
        </style>
    <![endif]-->

    <!-- All other clients get the webfont reference; some will render the font and others will silently fail to the fallbacks. More on that here: http://stylecampaign.com/blog/2015/02/webfont-support-in-email/ -->
    <!--[if !mso]><!-->
    <!-- insert web font reference, eg: <link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'> -->
    <!--<![endif]-->

    <!-- Web Font / @font-face : END -->

    <!-- CSS Reset : BEGIN -->
    <style>

        /* What it does: Remove spaces around the email design added by some email clients. */
        /* Beware: It can remove the padding / margin and add a background color to the compose a reply window. */
        html,
        body {
            margin: 0 auto !important;
            padding: 0 !important;
            height: 100% !important;
            width: 100% !important;
        }

        /* What it does: Stops email clients resizing small text. */
        * {
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }

        /* What it does: Centers email on Android 4.4 */
        div[style*='margin: 16px 0'] {
            margin: 0 !important;
        }

        /* What it does: Stops Outlook from adding extra spacing to tables. */
        table,
        td {
            mso-table-lspace: 0pt !important;
            mso-table-rspace: 0pt !important;
        }

        /* What it does: Fixes webkit padding issue. Fix for Yahoo mail table alignment bug. Applies table-layout to the first 2 tables then removes for anything nested deeper. */
        table {
            border-spacing: 0 !important;
            border-collapse: collapse !important;
            table-layout: fixed !important;
            margin: 0 auto !important;
        }
        table table table {
            table-layout: auto;
        }

        /* What it does: Uses a better rendering method when resizing images in IE. */
        img {
            -ms-interpolation-mode:bicubic;
        }

        /* What it does: A work-around for email clients meddling in triggered links. */
        *[x-apple-data-detectors],  /* iOS */
        .unstyle-auto-detected-links *,
        .aBn {
            border-bottom: 0 !important;
            cursor: default !important;
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        /* What it does: Prevents Gmail from displaying a download button on large, non-linked images. */
        .a6S {
           display: none !important;
           opacity: 0.01 !important;
       }
       /* If the above doesn't work, add a .g-img class to any image in question. */
       img.g-img + div {
           display: none !important;
       }

       /* What it does: Prevents underlining the button text in Windows 10 */
        .button-link {
            text-decoration: none !important;
        }

        /* What it does: Removes right gutter in Gmail iOS app: https://github.com/TedGoas/Cerberus/issues/89  */
        /* Create one of these media queries for each additional viewport size you'd like to fix */

        /* iPhone 4, 4S, 5, 5S, 5C, and 5SE */
        @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
            .email-container {
                min-width: 320px !important;
            }
        }
        /* iPhone 6, 6S, 7, 8, and X */
        @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
            .email-container {
                min-width: 375px !important;
            }
        }
        /* iPhone 6+, 7+, and 8+ */
        @media only screen and (min-device-width: 414px) {
            .email-container {
                min-width: 414px !important;
            }
        }

    </style>
    <!-- CSS Reset : END -->
	<!-- Reset list spacing because Outlook ignores much of our inline CSS. -->
	<!--[if mso]>
	<style type='text/css'>
		ul,
		ol {
			margin: 0 !important;
		}
		li {
			margin-left: 30px !important;
		}
		li.list-item-first {
			margin-top: 0 !important;
		}
		li.list-item-last {
			margin-bottom: 10px !important;
		}
	</style>
	<![endif]-->

    <!-- Progressive Enhancements : BEGIN -->
    <style>

        /* What it does: Hover styles for buttons */
        .button-td,
        .button-a {
            transition: all 100ms ease-in;
        }
	    .button-td-primary:hover,
	    .button-a-primary:hover {
	        background: #555555 !important;
	        border-color: #555555 !important;
	    }

        /* Media Queries */
        @media screen and (max-width: 600px) {

            .email-container {
                width: 100% !important;
                margin: auto !important;
            }

            /* What it does: Forces elements to resize to the full width of their container. Useful for resizing images beyond their max-width. */
            .fluid {
                max-width: 100% !important;
                height: auto !important;
                margin-left: auto !important;
                margin-right: auto !important;
            }

            /* What it does: Forces table cells into full-width rows. */
            .stack-column,
            .stack-column-center {
                display: block !important;
                width: 100% !important;
                max-width: 100% !important;
                direction: ltr !important;
            }
            /* And center justify these ones. */
            .stack-column-center {
                text-align: center !important;
            }

            /* What it does: Generic utility class for centering. Useful for images, buttons, and nested tables. */
            .center-on-narrow {
                text-align: center !important;
                display: block !important;
                margin-left: auto !important;
                margin-right: auto !important;
                float: none !important;
            }
            table.center-on-narrow {
                display: inline-block !important;
            }

            /* What it does: Adjust typography on small screens to improve readability */
            .email-container p {
                font-size: 17px !important;
            }
        }

    </style>
    <!-- Progressive Enhancements : END -->

    <!-- What it does: Makes background images in 72ppi Outlook render at correct size. -->
    <!--[if gte mso 9]>
    <xml>
        <o:OfficeDocumentSettings>
            <o:AllowPNG/>
            <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
    </xml>
    <![endif]-->

</head>
<!--
	The email background color (#222222) is defined in three places:
	1. body tag: for most email clients
	2. center tag: for Gmail and Inbox mobile apps and web versions of Gmail, GSuite, Inbox, Yahoo, AOL, Libero, Comcast, freenet, Mail.ru, Orange.fr
	3. mso conditional: For Windows 10 Mail
-->
<body width='100%' style='margin: 0; mso-line-height-rule: exactly; background-color: #222222;'>
    <center style='width: 100%; background-color: white; text-align: left;'>
    <!--[if mso | IE]>
    <table role='presentation' border='0' cellpadding='0' cellspacing='0' width='100%' style='background-color: #222222;'>
    <tr>
    <td>
    <![endif]-->

        <!-- Visually Hidden Preheader Text : BEGIN -->
        <div style='display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;'>
            (Optional) This text will appear in the inbox preview, but not the email body. It can be used to supplement the email subject line or even summarize the email's contents. Extended text preheaders (~490 characters) seems like a better UX for anyone using a screenreader or voice-command apps like Siri to dictate the contents of an email. If this text is not included, email clients will automatically populate it using the text (including image alt text) at the start of the email's body.
        </div>
        <!-- Visually Hidden Preheader Text : END -->

        <!-- Create white space after the desired preview text so email clients don’t pull other distracting text into the inbox preview. Extend as necessary. -->
        <!-- Preview Text Spacing Hack : BEGIN -->
        <div style='display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;'>
	        &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
        </div>
        <!-- Preview Text Spacing Hack : END -->

        <!-- Email Header : BEGIN -->
        <table role='presentation' cellspacing='0' cellpadding='0' border='0' align='center' width='600' style='margin: auto;' class='email-container'>
            <tr>
                <td style='padding: 20px 0; text-align: center'>
                    <img src='https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/31944804_119859008880931_7680956372128628736_n.jpg?_nc_cat=0&oh=0a6a6a255aeae4fc881a1d9aff57420e&oe=5B98BF94' width='50px' height='50px' alt='alt_text' border='0' style='height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'>
                </td>
            </tr>
        </table>
        <!-- Email Header : END -->

        <!-- Email Body : BEGIN -->
        <table role='presentation' cellspacing='0' cellpadding='0' border='0' align='center' width='600' style='margin: auto;' class='email-container'>

            <!-- Hero Image, Flush : BEGIN -->
            <tr>
                <td align='center' style='background-color: #ffffff;'>
                    <img src='https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/31964177_119876202212545_3036200527156215808_o.jpg?_nc_cat=0&oh=285b9d25c3539b97c46e2451b6bce4f7&oe=5B5AAEFA' width='600' height='' alt='alt_text' border='0' align='center' style='width: 100%; max-width: 600px; height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; margin: auto;' class='g-img'>
                </td>
            </tr>
            <!-- Hero Image, Flush : END -->

            <!-- 1 Column Text + Button : BEGIN -->
            <tr>
                <td style='background-color: #ffffff;'>
                    <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
                        <tr>
                            <td style='padding: 40px 40px 20px; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'>
							<h1 style='margin: 0 0 10px; font-size: 24px; line-height: 125%; color: #333333; font-weight: normal;text-align: center;'>F&R Store</h1>
                                <h1 style='margin: 0 0 10px; font-size: 24px; line-height: 125%; color: #333333; font-weight: normal;'>Hi, $eem </h1>
                                <p style='margin: 0 0 10px;'>Ini Link untuk Mengganti Password Kamu :</p>
                                <ul style='padding: 0; margin: 0; list-style-type: none;'>
									<li style='margin:0 0 10px 30px;color:red;' class='list-item-first'><a href='farrasmuttaqin1.000webhostapp.com/gantiganti.php?email=$eem'>Link Ganti Password</a></li>
								</ul>
								<p style='margin: 0 0 10px;'>Silahkan Login Kembali dan Berbelanja, Terima Kasih...</p>
                            </td>
                        </tr>
                        <tr>
                            <td style='padding: 0 40px 40px; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'>
                                <!-- Button : BEGIN -->
                                <table role='presentation' cellspacing='0' cellpadding='0' border='0' align='center' style='margin: auto;'>
                                    <tr>
                                        <td class='button-td button-td-primary' style='border-radius: 4px; background: #222222;'>
										     <a class='button-a button-a-primary' href='http://farrasmuttaqin1.000webhostapp.com/login.php' style='background: #222222; border: 1px solid #000000; font-family: sans-serif; font-size: 15px; line-height: 15px; text-decoration: none; padding: 13px 17px; display: block; border-radius: 4px;'><span class='button-link' style='color:#ffffff'>Login</span></a>
										</td>
                                    </tr>
                                </table>
                                <!-- Button : END -->
                            </td>
                        </tr>

                    </table>
                </td>
            </tr>
            <!-- 1 Column Text + Button : END -->

            <!-- Background Image with Text : BEGIN -->
            
	        <!-- Background Image with Text : END -->

	        <!-- 2 Even Columns : BEGIN -->
	        <tr>
	            <td align='center' valign='top' style='padding: 10px; background-color: #ffffff;'>
	                <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
	                    <tr>
	                        <!-- Column : BEGIN -->
	                        <!-- Column : END -->
	                        <!-- Column : BEGIN -->
	                        <td class='stack-column-center'>
	                            <table role='presentation' cellspacing='0' cellpadding='0' border='0'>
	                               
	                                <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;text-align:center;'>CEO F&R Store</p>
	                                    </td>
	                                </tr>
									 <tr>
	                                    <td style='padding: 10px; text-align: center'>
	                                        <img src='https://scontent-sin6-1.xx.fbcdn.net/v/t1.0-9/31944928_119881925545306_1971321295157067776_n.jpg?_nc_cat=0&oh=10b316019c0cc3f3768078e2a7468601&oe=5B8A7370' width='270' height='270' alt='alt_text' border='0' class='fluid' style='height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'>
	                                    </td>
	                                </tr>
									  <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;text-align:center;'>Muhammad Farras Muttaqin</p>
	                                    </td>
	                                </tr>
									<tr>
										<td><br></td>
									</tr>
									 <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;text-align:center;'>Ikuti kami di,</p>
	                                    </td>
	                                </tr>
	                            </table>
	                        </td>
	                        <!-- Column : END -->
	                    </tr>
	                </table>
	            </td>
	        </tr>
	        <!-- 2 Even Columns : END -->

	        <!-- 3 Even Columns : BEGIN -->
	        <tr>
	            <td align='center' valign='top' style='padding: 10px; background-color: #ffffff;'>
	                <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
	                    <tr>
	                        <!-- Column : BEGIN -->
	                        <td width='33.33%' class='stack-column-center'>
	                            <table role='presentation' cellspacing='0' cellpadding='0' border='0'>
	                                <tr>
	                                    <td style='padding: 10px; text-align: center'>
	                                        <a href='https://www.facebook.com/faraf.styles.5?ref=bookmarks'><img src='https://cdn4.iconfinder.com/data/icons/social-media-icons-the-circle-set/48/facebook_circle-512.png' width='70' height='70' alt='alt_text' border='0' class='fluid' style='height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'></a>
	                                    </td>
	                                </tr>
	                                <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;'></p>
	                                    </td>
	                                </tr>
	                            </table>
	                        </td>
	                        <!-- Column : END -->
	                        <!-- Column : BEGIN -->
	                        <td width='33.33%' class='stack-column-center'>
	                            <table role='presentation' cellspacing='0' cellpadding='0' border='0'>
	                                <tr>
	                                    <td style='padding: 10px; text-align: center'>
	                                        <a href='https://plus.google.com/106161117740575528724'><img src='https://upload.wikimedia.org/wikipedia/commons/f/fb/Google-plus-circle-icon-png.png' width='70' height='70' alt='alt_text' border='0' class='fluid' style='height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'></a>
	                                    </td>
	                                </tr>
	                                <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;'></p>
	                                    </td>
	                                </tr>
	                            </table>
	                        </td>
	                        <!-- Column : END -->
	                        <!-- Column : BEGIN -->
	                        <td width='33.33%' class='stack-column-center'>
	                            <table role='presentation' cellspacing='0' cellpadding='0' border='0'>
	                                <tr>
	                                    <td style='padding: 10px; text-align: center'>
	                                        <a href='https://twitter.com/FarafStyle'><img src='https://cdn4.iconfinder.com/data/icons/social-media-icons-the-circle-set/48/twitter_circle-512.png' width='70' height='70' alt='alt_text' border='0' class='fluid' style='height: auto; background: #dddddd; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555;'></a>
	                                    </td>
	                                </tr>
	                                <tr>
	                                    <td style='font-family: sans-serif; font-size: 15px; line-height: 140%; color: #555555; padding: 0 10px 10px; text-align: left;' class='center-on-narrow'>
	                                        <p style='margin: 0;'></p>
	                                    </td>
	                                </tr>
	                            </table>
	                        </td>
	                        <!-- Column : END -->
	                    </tr>
	                </table>
	            </td>
	        </tr>
	        <!-- 3 Even Columns : END -->

	        <!-- Thumbnail Left, Text Right : BEGIN -->
	        
	        <!-- Thumbnail Left, Text Right : END -->

	        <!-- Thumbnail Right, Text Left : BEGIN -->
	       
	        <!-- Thumbnail Right, Text Left : END -->

	        <!-- Clear Spacer : BEGIN -->
	        
	        <!-- Clear Spacer : END -->

	        <!-- 1 Column Text : BEGIN -->
	        
	        <!-- 1 Column Text : END -->

	    </table>
	    <!-- Email Body : END -->

	    <!-- Email Footer : BEGIN -->
	    
	    <!-- Email Footer : END -->

	    <!-- Full Bleed Background Section : BEGIN -->
	    <table role='presentation' cellspacing='0' cellpadding='0' border='0' align='center' width='100%' style='background-color: #709f2b;'>
	        <tr>
	            <td valign='top' align='center'>
	                <div style='max-width: 600px; margin: auto;' class='email-container'>
	                    <!--[if mso]>
	                    <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='600' align='center'>
	                    <tr>
	                    <td>
	                    <![endif]-->
	                    <table role='presentation' cellspacing='0' cellpadding='0' border='0' width='100%'>
							 <tr>
	                            <td style='padding: 40px; text-align: center; font-family: sans-serif; font-size: 15px; line-height: 140%; color: #ffffff;'>
								<p style='margin: 0;'>+62 812 9688 6565</p> <br>
	                                <p style='margin: 0;'>No 02, rt 01/016, Kelurahan Harapan Indah, Kecamatan Bekasi Selatan, Kabupaten Bekasi, Jawa Barat, 17124, Indonesia.</p>
									<br>
									© 2018 F&R Store, All rights reserved.
	                            </td>
	                        </tr>
	                    </table>
	                    <!--[if mso]>
	                    </td>
	                    </tr>
	                    </table>
	                    <![endif]-->
	                </div>
	            </td>
	        </tr>
	    </table>
	    <!-- Full Bleed Background Section : END -->

    <!--[if mso | IE]>
    </td>
    </tr>
    </table>
    <![endif]-->
    </center>
</body>
</html>

                                      

                                                        
                                        ";
                                       $headers = "Content-type: text/html; charset=iso-8859-1\n";
                                        $headers .= 'From:mfarrasmuttaqin | f&rStore @f&rstore.com' . "\r\n"; // Set from headers
                                        mail($to, $subject, $message, $headers); // Send our email
                            		}
                	        }
                        ?>
					</form>
					
				</div>
			</div>
		</div>
		<!-- newsletter -->
	<div class="newsletter">
		<div class="container">
			<div class="col-md-6 w3agile_newsletter_left">
				<h3>Newsletter</h3>
				<br>
				<p>Subscribe website kami untuk mendapatkan berita terbaru!!</p>
			</div>
			<?php
			error_reporting(E_ERROR | E_PARSE);
			    $email = $_POST["Email"];
			    
			    if ($email=="")
			    {
			        echo "";
			    }
			    else
			    {
			        $conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
			        $sql = "INSERT INTO news (email_news) VALUES ('$email')";
			        
			        if ($conn->query($sql) === TRUE) {
                        echo "";
                    } else {
                        echo "";
                    }
                    
                    $conn->close();
			    }
			?>
			<div class="col-md-6 w3agile_newsletter_right">
				<form method="post" id="myForm" action="forgotPassword.php" onSubmit="alert('Terima kasih atas subscribenya :) .');" >
					<input type="email" name="Email" placeholder="Masukkan Email.." required>
					<input type="submit" value="Subscribe" />
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //newsletter -->
<div class="footer">
	<div class="container">
		<div class="col-md-3 footer-grids fgd1">
		<a href="index.php"><img src="images/logo2.png" alt=" " /><h3>f&r Store</h3></a>
		<ul>
			<li>No 02, RT 001/012,</li>
			<li>Kabupaten Bekasi, Indonesia.</li>
			<li><a href="mailto:frstoreee@gmail.com">frstoreee@gmail.com</a></li>
			<a href="https://twitter.com/motivasinesia"><i class="fa fa-twitter" aria-hidden="true"></i></a>
			<a href="https://www.facebook.com/faraf.styles.5?ref=bookmarks"><i class="fa fa-facebook" aria-hidden="true"></i></a>
			<a href="https://www.linkedin.com/in/farras-muttaqin-59259412a/"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
		</ul>
		</div>
		<div class="col-md-3 footer-grids fgd2">
			<h4>Information</h4> 
			<ul>
				<li><a href="contact.php">Contact Us</a></li>
				<li><a href="about.php">About</a></li>
			</ul>
		</div>
		<div class="col-md-3 footer-grids fgd3">
			<h4>Shop</h4> 
			<ul>
				<li><a href="jersey.php">Jersey</a></li>
				<li><a href="merchandise.php">Merchandise</a></li>
				<li><a href="furniture.php">Furniture</a></li>
			</ul>
		</div>
		<div class="col-md-3 footer-grids fgd4">
			<h4>My Account</h4> 
			<ul>
			    <?php
                		error_reporting(E_ERROR | E_PARSE);
                		session_start();
                		
                    		if ($_SESSION["namaq"]=="")
                    		{
                    		    echo " <li><a href='login.php'>Login </a></li>
                        			   <li><a href='register.php'>Register</a></li>
                        			   ";
                    		}
                    		else
                    		{
                    		    echo "  <li><a href='profiles.php'>Profile</a></li>
				                        <li><a href='payment.php'>Cara bayar / How to pay</a></li>";
                    		}

                    ?>
				
			</ul>
		</div>
		<div class="clearfix"></div>
		<p class="copy-right">&copy 2018 f&r Store, All rights reserved.</p>
	</div>
</div>

		<script src="vendor/animsition/js/animsition.min.js"></script>

	<script src="js/main.js"></script>
</body>
<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove();
    }); 
    </script>
</html>