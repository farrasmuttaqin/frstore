<?php
error_reporting(E_ERROR | E_PARSE);
                		
session_start();
   	
    if  ($_GET["jenis"]==""||$_GET["iid"]==""||$_GET["nums"]==""||$_SESSION["emailq"]=="")
    {
        echo "<script> window.location.assign('index.php'); </script>";
    }
    else
    {
        
        $email=$_SESSION["emailq"];
        
        $conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
        
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $id_user=$row["id_user"];
            }
        } else {
            echo "";
        }
    
        $conn->close();
        
        $tampung=$_GET["jenis"]; 
        $tampungID=$_GET["iid"]; 
        $quantity=$_GET["nums"];
        
        if ($tampung=="jersey")
            {
                $url = "http://renjershop.000webhostapp.com/server/serviceJerseyProduct.php?idp=$tampungID";
            }
        if ($tampung=="merchandise")
            {
                $url = "http://ahmadfaiz309.000webhostapp.com/server/serviceMerchandiseProduct.php?idp=$tampungID";
            }
        if ($tampung=="furniture")
            {
                $url = "http://rafiirizqullah23.000webhostapp.com/server/serviceFurnitureProduct.php?idp=$tampungID";
            }
        
        $curl = curl_init();
        curl_setopt($curl , CURLOPT_URL, $url);
        curl_setopt($curl , CURLOPT_HEADER,0);
        curl_setopt($curl , CURLOPT_RETURNTRANSFER, true);
        $xml = new SimpleXMLElement(curl_exec($curl));
        curl_close($curl);
        
        foreach ($xml->nama as $product):
    
            $nm=$product;
            $tampungHarga=$product["harga"];
            $desSingkat=$product["desSingkat"];
            $desPanjang=$product["desPanjang"];
            $addInfo=$product["addInfo"];
            $g1=$product["g1"];
            $yellowStar=$product["rating"];
            $merk=$product["merk"];
            $tahun=$product["tahun"];
    
        endforeach;
        
        if ($quantity==0)
        {
        	echo "<script> window.location.assign('product.php?idd=$tampungID&tmp=$tampung'); </script>";
        }
        else
        {
    		$conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
            
    		$sql = "insert into cart(id_user,nomor_invoice,kode_product,quantity,nama_product,harga_product,gambar_product,jenis_product,email) values('$id_user',101,'$tampungID','$quantity','$nm','$tampungHarga','$g1','$tampung','$email')";
    		
            		if ($conn->query($sql) === TRUE) {
            		    echo "<script> window.location.assign('product.php?idd=$tampungID&tmp=$tampung'); </script>";
            		 
            		}
            		else
            		{
            		    echo "";
            
            		}
    		$conn->close();
        }
    }

?>