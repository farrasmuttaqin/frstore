<?php
error_reporting(E_ERROR | E_PARSE);
                		
session_start();
   	
    if  ($_GET["kode_product"]==""||$_SESSION["emailq"]=="")
    {
        echo "<script> window.location.assign('index.php'); </script>";
    }
    else
    {
        $kode_product=$_GET["kode_product"];
        $email=$_SESSION["emailq"];
        
        if ($_GET["minus"]==1)
        {
            $minus=$_GET["minus"];
            $conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
        
            $sql = "UPDATE cart SET quantity=quantity-$minus WHERE kode_product=$kode_product AND email='$email'";

            if ($conn->query($sql) === TRUE) {
                echo "<script> window.location.assign('carts.php'); </script>";
            } else {
                echo "Error updating record: " . $conn->error;
            }
            $conn->close();
        }
        else
        {
            echo "";
        }
        if ($_GET["plus"]==1)
        {
            $plus=$_GET["plus"];
            $conn = mysqli_connect("localhost","id4159098_fashionlc","farras9988","id4159098_fashion");
        
            $sql = "UPDATE cart SET quantity=quantity+$plus WHERE kode_product=$kode_product AND email='$email'";

            if ($conn->query($sql) === TRUE) {
                echo "<script> window.location.assign('carts.php'); </script>";
            } else {
                echo "Error updating record: " . $conn->error;
            }
            $conn->close();
        }
        else
        {
            echo "";
        }
    }
    echo "<script> window.location.assign('carts.php'); </script>";
?>